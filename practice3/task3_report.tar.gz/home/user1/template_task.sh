#!/bin/bash

SCRIPT_NAME=$(basename "$0")
LOG="$(dirname "$0")/report_${SCRIPT_NAME}.log"
PIPE=/tmp/run/cuckoo.pid

if [ "$SCRIPT_NAME" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт запущен" >> "$LOG"

REQUEST="${SCRIPT_NAME}[$$]: how much time do I have?"
echo "$REQUEST" > "$PIPE" &
sleep 0.5
read -r N < "$PIPE"

sleep "$N"

echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт завершился, работал $N секунд." >> "$LOG"
