#!/bin/bash

SCRIPT_DIR="$(dirname "$0")"
CONF="$SCRIPT_DIR/observer.conf"
LOG="$SCRIPT_DIR/observer.log"

while IFS= read -r script_path; do
    [ -z "$script_path" ] && continue
    script_name=$(basename "$script_path")

    found=0
    for cmdline_file in /proc/[0-9]*/cmdline; do
        cmdline=$(tr '\0' ' ' < "$cmdline_file" 2>/dev/null)
        if echo "$cmdline" | grep -q "$script_name"; then
            found=1
            break
        fi
    done

    if [ "$found" -eq 0 ]; then
        nohup bash "$script_path" >> "$LOG" 2>&1 &
        echo "$(date '+%Y-%m-%d %H:%M:%S') Перезапущен: $script_name" >> "$LOG"
    fi
done < "$CONF"
