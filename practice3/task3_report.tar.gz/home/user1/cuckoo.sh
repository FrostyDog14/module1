#!/bin/bash

PIPE=/tmp/run/cuckoo.pid
LOG=/tmp/run/cuckoo.log
mkdir -p /tmp/run

[ -p "$PIPE" ] || mkfifo "$PIPE"

cleanup() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') Shutdown!" >> "$LOG"
    rm -f "$PIPE"
    exit 0
}
trap cleanup SIGTERM

echo "$(date '+%Y-%m-%d %H:%M:%S') Startup!" >> "$LOG"

while true; do
    read -r line < "$PIPE"
    if echo "$line" | grep -qE '^.+\[[0-9]+\]: how much time do I have\?$'; then
        NAME_PID=$(echo "$line" | grep -oE '^.+\[[0-9]+\]')
        N=$(( RANDOM % 9 + 2 ))
        echo "$N" > "$PIPE" &
        echo "$(date '+%Y-%m-%d %H:%M:%S') $NAME_PID $N" >> "$LOG"
    fi
done
