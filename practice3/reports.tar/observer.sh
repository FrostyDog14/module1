#!/bin/bash

# Файл конфигурации со списком скриптов
config_file="scripts_list.txt"

# Лог-файл для записи информации о перезапуске
log_file="observer.log"

# Читаем список скриптов из файла конфигурации
while IFS= read -r script; do
    # Проверяем, запущен ли скрипт
    if ! pgrep -f "$script" > /dev/null; then
        # Если скрипт не запущен, запускаем его в фоновом режиме
        nohup "$script" > /dev/null 2>&1 &
        # Записываем информацию о перезапуске в лог-файл
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Запущен скрипт: $script" >> "$log_file"
    fi
done < "$config_file"
